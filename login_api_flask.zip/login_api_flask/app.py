from flask import Flask, request, jsonify, make_response
import pymysql
import pymysql.cursors

app = Flask(__name__)

# ---------------------- KONEKSI DB ----------------------
def get_db_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='',
        database='rfid_database',
        cursorclass=pymysql.cursors.DictCursor
    )

# ---------------------- CORS RESPONSE ----------------------
def make_cors_response(data, status=200):
    response = make_response(data, status)
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    return response

# ---------------------- CEK UID (TABEL USERS) ----------------------
@app.route('/check_uid', methods=['GET'])
def check_uid():
    uid = request.args.get('uid')
    if not uid:
        return '0'
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT allowed FROM users WHERE uid = %s", (uid,))
        result = cursor.fetchone()
        return '1' if result and result['allowed'] == 1 else '0'
    except Exception as e:
        print("DB Error (check_uid):", e)
        return '0'
    finally:
        cursor.close()
        conn.close()

# ---------------------- MOBIL MASUK ----------------------
@app.route('/mobil_masuk', methods=['POST'])
def mobil_masuk():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Kurangi slot jika masih tersedia
        cursor.execute("SELECT total_slot FROM slot WHERE id = 1")
        row = cursor.fetchone()
        if row and row['total_slot'] > 0:
            cursor.execute("UPDATE slot SET total_slot = total_slot - 1 WHERE id = 1")
            conn.commit()
            return 'OK'
        else:
            return 'PENUH'
    except Exception as e:
        print("DB Error (mobil_masuk):", e)
        return 'FAIL'
    finally:
        cursor.close()
        conn.close()

# ---------------------- MOBIL KELUAR ----------------------
@app.route('/mobil_keluar', methods=['POST'])
def mobil_keluar():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE slot SET total_slot = total_slot + 1 WHERE id = 1")
        conn.commit()
        return 'OK'
    except Exception as e:
        print("DB Error (mobil_keluar):", e)
        return 'FAIL'
    finally:
        cursor.close()
        conn.close()

# ---------------------- STATUS PARKIR ----------------------
@app.route('/status_parkir', methods=['GET'])
def status_parkir():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT total_slot FROM slot WHERE id = 1")
        row = cursor.fetchone()
        if not row:
            return jsonify({"error": "Data slot tidak ditemukan."}), 404
        total_capacity = 3  # Ganti sesuai kapasitas maksimal
        available = row['total_slot']
        return jsonify({
            "total": total_capacity,
            "available": available
        })
    except Exception as e:
        print("DB Error (status_parkir):", e)
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

# ---------------------- TAMPILKAN SEMUA USERS ----------------------
@app.route('/list_users', methods=['GET'])
def list_users():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, uid, allowed FROM users")
        results = cursor.fetchall()
        return jsonify(results)
    except Exception as e:
        print("DB Error (list_users):", e)
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        conn.close()

# ---------------------- USERSLOGIN (nama & password saja) ----------------------
@app.route('/userslogin', methods=['GET'])
def get_all_userslogin():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT nama, password FROM userslogin")
        users = cursor.fetchall()
        return make_cors_response(jsonify(users))
    except Exception as e:
        print("Get UsersLogin Error:", e)
        return make_cors_response(jsonify({'error': str(e)}), 500)
    finally:
        cursor.close()
        conn.close()

@app.route('/userslogin', methods=['POST'])
def add_userlogin():
    nama = request.form.get('nama')
    password = request.form.get('password')
    if not nama or not password:
        return make_cors_response('empty')
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO userslogin (nama, password) VALUES (%s, %s)", (nama, password))
        conn.commit()
        return make_cors_response('success')
    except Exception as e:
        print("Add UserLogin Error:", e)
        return make_cors_response('error')
    finally:
        cursor.close()
        conn.close()

# ---------------------- HALAMAN UTAMA ----------------------
@app.route('/')
def index():
    return "API RFID aktif"

# ---------------------- JALANKAN FLASK ----------------------
if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
