from flask import Flask, request, jsonify
import pymysql
import pymysql.cursors

app = Flask(__name__)

# Fungsi untuk membuat koneksi baru setiap request
def get_db_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='',
        database='rfid_database',
        cursorclass=pymysql.cursors.DictCursor  # hasil berupa dict
    )

# Endpoint untuk mengecek UID
@app.route('/check_uid', methods=['GET'])
def check_uid():
    uid = request.args.get('uid')
    if not uid:
        return '0'

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT allowed FROM users WHERE uid = %s", (uid,))
        result = cursor.fetchone()
        cursor.close()
        conn.close()

        if result and result['allowed'] == 1:
            return '1'
        else:
            return '0'
    except Exception as e:
        print("DB Error:", e)
        return '0'

# Endpoint untuk menampilkan semua user
@app.route('/list_users', methods=['GET'])
def list_users():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, uid, allowed FROM users")
        results = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify(results)
    except Exception as e:
        print("DB Error:", e)
        return jsonify({'error': str(e)}), 500

# Jalankan Flask agar bisa diakses dari ESP32
if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
